/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller;

import Dao.DaoCliente;
import Model.Cliente;
import Model.ClienteDel;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Desktop
 */
public class DadosCliente extends Conexao {
    
     public void cadastrar(Cliente cli) throws Exception {
        //abrir uma conexÃ£o
        String sql = "insert into cliente (nome, endereco, telefone, cpf, rg) value (?, ?, ?, ?, ?)";
        PreparedStatement pStatement = null;
        Connection connection = null;
        
         try{
              
            connection = new Conexao().getConnection();
            pStatement = connection.prepareStatement(sql);
            pStatement.setString(1, cli.getNome());
            pStatement.setString(2, cli.getEndereco());
            pStatement.setString(3, cli.getTelefone());
            pStatement.setString(4, cli.getCpf());
            pStatement.setString(5, cli.getRg());
          
            pStatement.execute();
            
        }catch(SQLException e){
            throw new DaoCliente("Erro ao cadastrar cliente! " + e);
            
        } finally {
            
            
            
        } try {
            if(pStatement != null) {pStatement.close();}
        } catch(SQLException e){
            throw new DaoCliente("Erro ao fechar o Statement! " + e);
            
            
        } try {
            if (connection != null) {connection.close();}
        } catch(SQLException e) {
            throw new DaoCliente("Erro ao fechar a conexão! " + e);
        }
    }
        
     
    public void atualizar(Cliente cli) throws Exception {
        
        String sql = "UPDATE cliente SET nome = ? WHERE cpf = ? ";
        PreparedStatement pStatement = null;
        Connection connection = null;
        
        try{
              
            connection = new Conexao().getConnection();
            pStatement = connection.prepareStatement(sql);
            pStatement.setString(1, cli.getNome());
            pStatement.setString(2, cli.getCpf());
          
            pStatement.execute();
            
        }catch(SQLException e){
            throw new DaoCliente("Erro ao atualizar cliente! " + e);
            
        } finally {
            
            
            
        } try {
            if(pStatement != null) {pStatement.close();}
        } catch(SQLException e){
            throw new DaoCliente("Erro ao fechar o Statement! " + e);
            
            
        } try {
            if (connection != null) {connection.close();}
        } catch(SQLException e) {
            throw new DaoCliente("Erro ao fechar a conexão! " + e);
        }
        
    }
    
    public void remover(ClienteDel cli) throws Exception {
        
        String sql = "DELETE FROM cliente WHERE cpf = ? ";
        PreparedStatement pStatement = null;
        Connection connection = null;
        
        try{
              
            connection = new Conexao().getConnection();
            pStatement = connection.prepareStatement(sql);
    
            pStatement.setString(1, cli.getCpf());
          
            pStatement.execute();
            
        }catch(SQLException e){
            throw new DaoCliente("Erro ao Remover cliente! " + e);
            
        } finally {
            
            
            
        } try {
            if(pStatement != null) {pStatement.close();}
        } catch(SQLException e){
            throw new DaoCliente("Erro ao fechar o Statement! " + e);
            
            
        } try {
            if (connection != null) {connection.close();}
        } catch(SQLException e) {
            throw new DaoCliente("Erro ao fechar a conexão! " + e);
        }
       
    }
}
