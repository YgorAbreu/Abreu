/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Dao;

/**
 *
 * @author Desktop
 */
public class DaoCliente extends Exception{
    public DaoCliente(String mensagem){
        super(mensagem);
}
}
