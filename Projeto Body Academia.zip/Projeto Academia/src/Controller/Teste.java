/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller;

/**
 *
 * @author Desktop
 */
public class Teste {
    
    public static void main (String[] args) {
    
        try {
            Conexao c = new Conexao();
            //c.abrirConexao(); 
            System.out.println("conexão aberta");
            //c.fecharConexao();
            System.out.println("conexão fechada");
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }   
}
