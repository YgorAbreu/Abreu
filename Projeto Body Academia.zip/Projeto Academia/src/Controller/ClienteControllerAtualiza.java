/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller;

import Dao.DaoCliente;
import Model.Cliente;

/**
 *
 * @author Desktop
 */
public class ClienteControllerAtualiza {
    public boolean cadastraCliente(String nome, String endereco, String telefone, String cpf, String rg) throws DaoCliente, Exception{
        
        if( nome != null && nome.length() > 0 && endereco != null && endereco.length() > 0 && telefone != null && telefone.length() > 0 && cpf != null && cpf.length() > 0 && rg != null && rg.length() > 0) {
        
            Cliente cliente = new Cliente(nome, endereco, telefone, cpf, rg);
            DadosCliente cli = new DadosCliente();
            cli.atualizar(cliente);
            return true;
            
        }
        
        return false;
    }
}
