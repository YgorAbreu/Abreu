/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller;

import Dao.DaoCliente;
import Model.ClienteDel;
import Model.Cliente;

/**
 *
 * @author Desktop
 */
public class ClienteControllerRemover {
    public boolean cadastraCliente(String cpf) throws DaoCliente, Exception{
        
        if( cpf != null && cpf.length() > 0 ) {
        
            ClienteDel cliente = new ClienteDel(cpf);
            DadosCliente cli = new DadosCliente();
            cli.remover(cliente);
            return true;
            
        }
        
        return false;
    }
}
