/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

/**
 *
 * @author Desktop
 */
public class Instrutor {
    
    private Integer codFunc;
    private String endereço;
    private String nome;
    private Integer telefone;
    private Integer idade;
    private String usuario;
    
}
